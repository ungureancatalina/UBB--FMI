from string_de_optiuni import citire_optiune

citire_optiune()