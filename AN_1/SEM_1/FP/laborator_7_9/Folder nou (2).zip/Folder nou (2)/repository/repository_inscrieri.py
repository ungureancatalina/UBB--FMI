from repository.repository_persoane import RepositoryPersoane
from repository.repository_evenimente import RepositoryEvenimente

class RepositoryInscrieri:
    def __init__(self,lista_persoane: RepositoryPersoane,lista_evenimente:RepositoryEvenimente):
        self.__lista_inscrieri= []
        self.__lista_persoane = lista_persoane
        self.__lista_evenimente = lista_evenimente
    
    def cauta_persoana(self, personID:int):
        '''
        Functie ce afiseaza daca exista aceasta persoana din lista
        :param: personID
        :type: int
        :return: persoana
        '''
        for persoana in self.__lista_persoane.get_lista_persoane():
            if persoana.get_id()==personID:
                return True
        return False             
    
    def cauta_inscriere(self, personID:int, ID:int):
        '''
        Functie ce afiseaza daca exista aceasta persoana din lista
        :param: personID
        :type: int
        :param: ID
        :type: int
        :return: true or false
        '''
        for persoana,eveniment in self.__lista_inscrieri:
            if persoana==personID and eveniment==ID:
                return True    
        return False        
    
    def cauta_eveniment(self, ID:int):
        '''
        Functie ce afiseaza daca exista acest eveniment din lista
        :param: ID
        :type: int
        :return: eveniment
        '''
        for eveniment in self.__lista_evenimente.get_lista_evenimente():
            if eveniment.get_id()==ID:
                return True
        return False       
        
    def adauga(self, persoanaID:int , evenimentID:int):
        '''
        Functie ce adauga pentru id-ul persoanei id-ul unui eveniment
        :param: personID
        :type: int
        :param: evenimentID
        :type: int
        :return: -
        '''
        if self.cauta_persoana(persoanaID)==False:
            raise ValueError("Nu exista persoana cu acest id.")
        if self.cauta_eveniment(evenimentID)==False :
            raise ValueError("Nu exista eveniment cu acest id.")
        if self.cauta_inscriere(persoanaID,evenimentID):
            raise ValueError("Exista deja aceasta inscriere")
        self.__lista_inscrieri.append([persoanaID,evenimentID])
        
    def get_lista_inscrieri(self):
        '''
        Functie ce returneaza lista de inscrieri
        :param: none
        :return: lista de inscrieri
        :rtype: list
        '''
        return self.__lista_inscrieri
        
    def get_evenimentele_persoanei(self,ID:int):
        '''
        Functie ce returneaza lista de evenimente ale unei persoane
        :param: ID
        :type: int
        :return: lista de evenimente ale unei persoane
        :rtype: list
        '''
        evenimente= []
        for id_persoana,id_eveniment in self.__lista_inscrieri:
            if id_persoana==ID:
                evenimente.append(id_eveniment)
        return evenimente
        
    def get_persoanele_evenimentului(self,ID:int):
        '''
        Functie ce returneaza lista de persoane ale unui eveniment
        :param: ID
        :type: int
        :return: lista de persoane ale unui eveniment
        :rtype: list
        '''
        persoane= []
        for id_persoana,id_eveniment in self.__lista_inscrieri:
            if id_eveniment==ID:
                persoane.append(id_persoana)
        return persoane